﻿namespace Prog2370LiamDowlingAssignment3
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.pbOne = new System.Windows.Forms.PictureBox();
			this.pbTwo = new System.Windows.Forms.PictureBox();
			this.pbThree = new System.Windows.Forms.PictureBox();
			this.pbSix = new System.Windows.Forms.PictureBox();
			this.pbFive = new System.Windows.Forms.PictureBox();
			this.pbFour = new System.Windows.Forms.PictureBox();
			this.pbSeven = new System.Windows.Forms.PictureBox();
			this.pbEight = new System.Windows.Forms.PictureBox();
			this.pbNine = new System.Windows.Forms.PictureBox();
			this.lblTop = new System.Windows.Forms.Label();
			((System.ComponentModel.ISupportInitialize)(this.pbOne)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pbTwo)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pbThree)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pbSix)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pbFive)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pbFour)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pbSeven)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pbEight)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pbNine)).BeginInit();
			this.SuspendLayout();
			// 
			// pbOne
			// 
			this.pbOne.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pbOne.Location = new System.Drawing.Point(274, 104);
			this.pbOne.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
			this.pbOne.Name = "pbOne";
			this.pbOne.Size = new System.Drawing.Size(77, 82);
			this.pbOne.TabIndex = 0;
			this.pbOne.TabStop = false;
			this.pbOne.Click += new System.EventHandler(this.PbOne_Click);
			// 
			// pbTwo
			// 
			this.pbTwo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pbTwo.Location = new System.Drawing.Point(359, 104);
			this.pbTwo.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
			this.pbTwo.Name = "pbTwo";
			this.pbTwo.Size = new System.Drawing.Size(77, 82);
			this.pbTwo.TabIndex = 0;
			this.pbTwo.TabStop = false;
			this.pbTwo.Click += new System.EventHandler(this.PbTwo_Click);
			// 
			// pbThree
			// 
			this.pbThree.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pbThree.Location = new System.Drawing.Point(442, 104);
			this.pbThree.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
			this.pbThree.Name = "pbThree";
			this.pbThree.Size = new System.Drawing.Size(77, 82);
			this.pbThree.TabIndex = 0;
			this.pbThree.TabStop = false;
			this.pbThree.Click += new System.EventHandler(this.PbThree_Click);
			// 
			// pbSix
			// 
			this.pbSix.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pbSix.Location = new System.Drawing.Point(442, 192);
			this.pbSix.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
			this.pbSix.Name = "pbSix";
			this.pbSix.Size = new System.Drawing.Size(77, 82);
			this.pbSix.TabIndex = 0;
			this.pbSix.TabStop = false;
			this.pbSix.Click += new System.EventHandler(this.PbSix_Click);
			// 
			// pbFive
			// 
			this.pbFive.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pbFive.Location = new System.Drawing.Point(359, 192);
			this.pbFive.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
			this.pbFive.Name = "pbFive";
			this.pbFive.Size = new System.Drawing.Size(77, 82);
			this.pbFive.TabIndex = 0;
			this.pbFive.TabStop = false;
			this.pbFive.Click += new System.EventHandler(this.PbFive_Click);
			// 
			// pbFour
			// 
			this.pbFour.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pbFour.Location = new System.Drawing.Point(274, 192);
			this.pbFour.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
			this.pbFour.Name = "pbFour";
			this.pbFour.Size = new System.Drawing.Size(77, 82);
			this.pbFour.TabIndex = 0;
			this.pbFour.TabStop = false;
			this.pbFour.Click += new System.EventHandler(this.PbFour_Click);
			// 
			// pbSeven
			// 
			this.pbSeven.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pbSeven.Location = new System.Drawing.Point(274, 280);
			this.pbSeven.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
			this.pbSeven.Name = "pbSeven";
			this.pbSeven.Size = new System.Drawing.Size(77, 82);
			this.pbSeven.TabIndex = 0;
			this.pbSeven.TabStop = false;
			this.pbSeven.Click += new System.EventHandler(this.PbSeven_Click);
			// 
			// pbEight
			// 
			this.pbEight.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pbEight.Location = new System.Drawing.Point(359, 280);
			this.pbEight.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
			this.pbEight.Name = "pbEight";
			this.pbEight.Size = new System.Drawing.Size(77, 82);
			this.pbEight.TabIndex = 0;
			this.pbEight.TabStop = false;
			this.pbEight.Click += new System.EventHandler(this.PbEight_Click);
			// 
			// pbNine
			// 
			this.pbNine.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pbNine.Location = new System.Drawing.Point(442, 280);
			this.pbNine.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
			this.pbNine.Name = "pbNine";
			this.pbNine.Size = new System.Drawing.Size(77, 82);
			this.pbNine.TabIndex = 0;
			this.pbNine.TabStop = false;
			this.pbNine.Click += new System.EventHandler(this.PbNine_Click);
			// 
			// lblTop
			// 
			this.lblTop.AutoSize = true;
			this.lblTop.Location = new System.Drawing.Point(241, 40);
			this.lblTop.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
			this.lblTop.Name = "lblTop";
			this.lblTop.Size = new System.Drawing.Size(0, 13);
			this.lblTop.TabIndex = 1;
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackgroundImage = global::Prog2370LiamDowlingAssignment3.Properties.Resources.Untitled_2;
			this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
			this.ClientSize = new System.Drawing.Size(795, 471);
			this.Controls.Add(this.lblTop);
			this.Controls.Add(this.pbNine);
			this.Controls.Add(this.pbEight);
			this.Controls.Add(this.pbSeven);
			this.Controls.Add(this.pbFour);
			this.Controls.Add(this.pbFive);
			this.Controls.Add(this.pbSix);
			this.Controls.Add(this.pbThree);
			this.Controls.Add(this.pbTwo);
			this.Controls.Add(this.pbOne);
			this.DoubleBuffered = true;
			this.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
			this.Name = "Form1";
			this.Text = "TIC TAC TOE";
			this.Load += new System.EventHandler(this.Form1_Load);
			((System.ComponentModel.ISupportInitialize)(this.pbOne)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pbTwo)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pbThree)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pbSix)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pbFive)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pbFour)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pbSeven)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pbEight)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pbNine)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.PictureBox pbOne;
		private System.Windows.Forms.PictureBox pbTwo;
		private System.Windows.Forms.PictureBox pbThree;
		private System.Windows.Forms.PictureBox pbSix;
		private System.Windows.Forms.PictureBox pbFive;
		private System.Windows.Forms.PictureBox pbFour;
		private System.Windows.Forms.PictureBox pbSeven;
		private System.Windows.Forms.PictureBox pbEight;
		private System.Windows.Forms.PictureBox pbNine;
		private System.Windows.Forms.Label lblTop;
	}
}

